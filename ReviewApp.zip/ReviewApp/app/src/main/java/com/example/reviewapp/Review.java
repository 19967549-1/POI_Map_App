package com.example.reviewapp;

public class Review {
    private final String id;
    private final String comment;

    public Review(String id, String comment) {
        this.id = id;
        this.comment = comment;
    }

    public String getComment() {
        return comment;
    }

    public String getId() {
        return id;
    }
}

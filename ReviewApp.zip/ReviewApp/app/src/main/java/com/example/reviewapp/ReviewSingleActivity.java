package com.example.reviewapp;

public class ReviewSingleActivity {
}

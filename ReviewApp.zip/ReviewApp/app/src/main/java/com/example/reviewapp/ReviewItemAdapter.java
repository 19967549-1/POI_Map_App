package com.example.reviewapp;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ReviewItemAdapter extends RecyclerView.Adapter<ReviewItemAdapter.ReviewViewHolder> {

    private final List<Review> reviewList;
    private final String TAG = "ReviewItemAdapter";

    public ReviewItemAdapter(List<Review> reviewList) {
        this.reviewList = reviewList;
    }

    @NonNull
    @Override
    public ReviewItemAdapter.ReviewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.review_item, parent, false);
        return new ReviewViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReviewViewHolder holder, int position) {
        Review review = reviewList.get(position);
        holder.reviewId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        holder.reviewComment.setText(review.getComment());
    }
    @Override
    public int getItemCount() {
        Log.e(TAG, "Review List Count in Review Adapter" +reviewList.size());
        return reviewList.size();
    }

    public static class ReviewViewHolder extends RecyclerView.ViewHolder {
        public TextView reviewComment;
        public ImageButton reviewId;

        public ReviewViewHolder(@NonNull View reviewView) {
            super(reviewView);
            reviewId = reviewView.findViewById(R.id.btnReviewMore);
            reviewComment = reviewView.findViewById(R.id.textReviewComment);
        }
    }
}

package com.example.reviewapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class ReviewActivity extends AppCompatActivity {
    private static final String TAG = "ReviewActivity";
    private final FirebaseFirestore db = FirebaseFirestore.getInstance();
    private  List<Review> reviewList;
    private RecyclerView recyclerView;
    private ReviewItemAdapter reviewItemAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reviews);
        Button createReviewBtn = findViewById(R.id.btnCreateReview);
        EditText reviewText = findViewById(R.id.etReviewComment);
        retrieveAndLoadReviews();
        createReviewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, Object> review = new HashMap<>();
                review.put("comment", reviewText.getText().toString());
                db.collection("reviews").add(review)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                                retrieveAndLoadReviews();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w(TAG, "Error adding document", e);
                            }
                        });
            }
        });
    }
    protected void retrieveAndLoadReviews() {
        db.collection("reviews")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()) {
                            recyclerView = findViewById(R.id.recyleViewReview);
                            recyclerView.setLayoutManager(new LinearLayoutManager(ReviewActivity.this));
                            reviewList = new ArrayList<Review>();
                            for(QueryDocumentSnapshot document: task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData());
                                Map<String, Object> data = document.getData();
                                String comment = "";
                                if(data.containsKey("comment")) {
                                    comment = (String) data.get("comment");
                                }
                                reviewList.add(new Review(document.getId(), comment));
                            }
                            Log.e(TAG, String.valueOf(reviewList.size()));
                            reviewItemAdapter = new ReviewItemAdapter(reviewList);
                            recyclerView.setAdapter(reviewItemAdapter);
                        } else {
                            Log.w(TAG, "Error getting documents.", task.getException());
                        }
                    }
                });
    }
}
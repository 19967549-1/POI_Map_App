package com.example.poi_locator;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    // Class Attributes:
    Button login_btn = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // listener for button click

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
        login_btn = (Button) findViewById(R.id.login_btn);

            login_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Snackbar login_btn_message = Snackbar.make(((View) findViewById(R.id.login_btn)),"THIS IS A TEST!!", 3600);
                    login_btn_message.show();
                    Log.d("login_btn_message",Integer.toString(login_btn_message.getDuration()));
                } //END onClick()
            });

          //System.out.println(e.toString());
        } // END CATCH STATEMENT
        } //END onCreate()




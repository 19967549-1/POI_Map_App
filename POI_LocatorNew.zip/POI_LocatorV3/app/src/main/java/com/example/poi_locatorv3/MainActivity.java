package com.example.poi_locatorv3;

import static android.app.ProgressDialog.show;
import static android.content.ContentValues.TAG;

import static com.google.android.material.internal.ContextUtils.getActivity;

import android.Manifest;
import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

//import androidx.activity.result.ActivityResultCallback;
//import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
// import com.example.POI_POI_Permission;
import android.util.Log;
import android.widget.EditText;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.ContentValues;
import android.content.Context;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

//import com.firebase.ui.auth.IdpResponse;
//import com.firebase.ui.auth.AuthUI;
//import com.firebase.ui.auth.FirebaseAuthUIActivityResultContract;/import com.firebase.ui.auth.data.model.FirebaseAuthUIAuthenticationResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;


import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.auth.FirebaseUser;

import com.google.firebase.firestore.DocumentReference;
//import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

//import java.util.Arrays;
import java.util.HashMap;
//import java.util.List;
import java.util.Map;

/*import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;*/

public class MainActivity extends AppCompatActivity{

    Button create_user = null;
    EditText username, pass = null;
    FirebaseFirestore db;
    //DocumentReference docRef;
    //FirebaseApp app;
    //Intent signInIntent =
    //List<AuthUI.IdpConfig> providers;

    TextView goodMorning;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        goodMorning = findViewById(R.id.test);
        username = findViewById(R.id.editUserName);
        pass = findViewById(R.id.editPassword);
        create_user = findViewById(R.id.create_user);
        db = FirebaseFirestore.getInstance();
        create_user.setOnClickListener(this::addPOI_LoginData);
        // sign_up = (Button) findViewById(R.id.Sign_up);
        //startActivity(new Intent(MainActivity.this, PermissionActivity.class));
    } //END onCreate METHOD

    private void addPOI_LoginData(View view) {
        Map<String, Object> loginDetails= new HashMap<>();

        loginDetails.put("Username",username.getText().toString());
        loginDetails.put("Password",pass.getText().toString());

        db.collection("login_details")
                .add(loginDetails)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d("DocumentSnapshot added with ID: ", "DocumentSnapshot added with ID: "
                                + documentReference.getId());
                    }
                })

                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d(TAG, "Error adding document", e);
                    }
                });
    } // END addPOI_LoginData METHOD


   /* private void switchActivity(View view) {
       // if(view.getClass().toString().equals("EditText")) {
            startActivity(new Intent(MainActivity.this,SignupActivity.class));
       // }
    }*/

     /*   @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            getMenuInflater().inflate(R.menu.main_menu, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            int id = item.getItemId();
            if (id == R.id.menu_search) {
                Intent intent = new Intent(this, SearchActivity.class);
                startActivity(intent);
                return true;
            }
            return super.onOptionsItemSelected(item);

        }
*/

          /*  final ActivityResultLauncher<Intent> signInLauncher = registerForActivityResult(
                    new FirebaseAuthUIActivityResultContract(),
                    new ActivityResultCallback<FirebaseAuthUIAuthenticationResult>() {
                        @Override
                        public void onActivityResult(FirebaseAuthUIAuthenticationResult result) {
                            onSignInResult(result);
                        }
                    }
            );

            // This code is from https://firebase.google.com/docs/auth/android/firebaseui#java
            // Choose authentication providers
            List<AuthUI.IdpConfig> providers = Arrays.asList(
                    new AuthUI.IdpConfig.EmailBuilder().build(),
                    new AuthUI.IdpConfig.PhoneBuilder().build(),
                    new AuthUI.IdpConfig.GoogleBuilder().build(),
                    new AuthUI.IdpConfig.FacebookBuilder().build(),
                    new AuthUI.IdpConfig.TwitterBuilder().build());

            // This code is from https://firebase.google.com/docs/auth/android/firebaseui#java
// Create and launch sign-in intent
            Intent signInIntent = AuthUI.getInstance()
                    .createSignInIntentBuilder()
                    .setAvailableProviders(providers)
                    .build();
            signInLauncher.launch(signInIntent);
*/
            // docRef = db.collection("POI_login").document("pj1ePkZ9mfHsgBHkgjps");
            // docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {

            // @param task

            // @Override
             /*    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                        } else {
                            Log.d(TAG, "No such document");
                        }
                    } else {
                        Log.d(TAG, "get failed with ", task.getException());
                    }
                }
            });
            */


        // onSignInResult code is from https://firebase.google.com/docs/auth/android/firebaseui#java
  /*  private void onSignInResult(FirebaseAuthUIAuthenticationResult result) {
        IdpResponse response = result.getIdpResponse();
        if (result.getResultCode() == RESULT_OK) {
            // Successfully signed in
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            // ...
        } else {
            // Sign in failed. If response is null the user canceled the
            // sign-in flow using the back button. Otherwise check
            // response.getError().getErrorCode() and handle the error.
            // ...
        }
    } */

        // Android Cryptography methods to add and move to separate Cryptography java file in testing phase.
          /* private void encryptMessage(String message) throws IllegalBlockSizeException, BadPaddingException {
                 int messageByteLen = message.getBytes().length;
                 byte[] plainText = new byte[messageByteLen];
               KeyGenerator keygen = KeyGenerator.getInstance("AES");
               keygen.init(256);
               SecretKey key = keygen.generateKey();
               Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
               cipher.init(Cipher.ENCRYPT_MODE, key);
               byte[] ciphertext = cipher.doFinal(plainText);
               byte[] iv = cipher.getIV()
           }*/

        // See: https://developer.android.com/training/basics/intents/result


    /*private final void chooseAuthProviders() {
        // Choose authentication providers
             providers = Arrays.asList(
                new AuthUI.IdpConfig.EmailBuilder().build(),
                new AuthUI.IdpConfig.PhoneBuilder().build(),
                new AuthUI.IdpConfig.GoogleBuilder().build(),
                new AuthUI.IdpConfig.FacebookBuilder().build(),
                new AuthUI.IdpConfig.TwitterBuilder().build());
    }

    private final void createSignInIntent() {
        // Create and launch sign-in intent
         AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(providers)
                .build();
        signInLauncher.launch(signInIntent);
    }
*/


    } // END MainActivity CLASS


package com.example.poi_locatorv3;

import static androidx.constraintlayout.widget.Constraints.TAG;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.activity.result.ActivityResultCaller;

public class PermissionActivity extends AppCompatActivity{
//implements ActivityResultCaller{
    final String[] PERMISSIONS = {android.Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};
    public PermissionActivity(){}
    //Required permissions array

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);
         requestPermissions(PERMISSIONS,1);
        //startActivity(new Intent(PermissionActivity.this,MainActivity.class));
    }
    //Result launcher for permissions
    /*private final ActivityResultLauncher<String[]> multiplePermissionActivityResultLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), isGranted -> {
                Log.d(TAG,"Launching multiple contract permission launcher for ALL required permissions");
                requestPermissions(PERMISSIONS,1);
                if (isGranted.containsValue(false)) {
                    Log.d(TAG, "At least one of the permissions was not granted, please enable permissions to ensure app functionality");
                }
            });*/
    //helper function to check permission status
   /*private boolean hasPermissions() {
        boolean permissionStatus = true;
        for (String permission : PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(this,permission) == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG,"Permission is granted: " + permission);
            } else {
                Log.d(TAG,"Permission is not granted: " + permission);
                permissionStatus = false;
            }
        }
        return permissionStatus;
    } // END hasPermissions METHOD

    //helper function to ask user permissions
    private void askPermissions() {
        if (!hasPermissions()) {
            Log.d(TAG, "Launching multiple contract permission launcher for ALL required permissions");
            multiplePermissionActivityResultLauncher.launch(PERMISSIONS);
        } else {
            Log.d(TAG, "All permissions are already granted");
        }
    } // ASK askPermissions METHOD
    */
} // END PermissionActivity CLASS



package com.example.poi_locatorv3;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class SignupActivity {
//extends AppCompatActivity {

   /*  Button create_user = null;

      EditText username =  findViewById(R.id.editUserName);
      EditText pass = findViewById(R.id.editPassword);

    FirebaseFirestore db;

    //public SignupActivity() {
      /*this.username = findViewById(R.id.editUserName);
        this.pass = (EditText) findViewById(R.id.editPassword);
        this.create_user = (Button) findViewById(R.id.create_user);*/
   // }
/*
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        db = FirebaseFirestore.getInstance();
        create_user = findViewById(R.id.create_user);
        create_user.setOnClickListener(this::addPOI_LoginData);
        startActivity(new Intent(SignupActivity.this,PermissionActivity.class));
        //Log.d(TAG, username.getText() + "\n");
        // Log.d(TAG,pass.toString() + "\n");
        //Log.d(TAG,create_user.getText()+ "\n");
    }

    private void addPOI_LoginData(View view) {
        Map<String, Object> loginDetails= new HashMap<>();

        loginDetails.put("Username",username.getText().toString());
        loginDetails.put("Password",pass.getText().toString());

        db.collection("login_details")
                .add(loginDetails)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d("DocumentSnapshot added with ID: ", "DocumentSnapshot added with ID: "
                                + documentReference.getId());
                    }
                })

                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d(TAG, "Error adding document", e);
                    }
                });
    } // END addPOI_LoginData METHOD
*/
    /*public void setUsername(){
            username = (EditText) findViewById(R.id.editUserName);
    }

    public EditText getUsername(){
        return username;
    }
*/

    //login_btn = findViewById(R.id.login_btn);

        /*login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               // Snackbar login_btn_message = Snackbar.make(((View) findViewById(R.id.login_btn)),"THIS IS A TEST!!", 3600);
                login_btn_message.show();
                Log.d("login_btn_message",Integer.toString(login_btn_message.getDuration()));
            }
        });*/

} // END OF SignupActivity Java CLASS

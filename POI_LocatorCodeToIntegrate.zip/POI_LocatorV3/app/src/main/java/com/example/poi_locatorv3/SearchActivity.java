package com.example.poi_locatorv3;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.LinearLayout;
public class SearchActivity extends AppCompatActivity{

    EditText searchEditText;
    Button searchButton;
    ImageButton imageSearchButton;
    ImageButton audioSearchButton;

    boolean isTextSearch = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        searchEditText = findViewById(R.id.search_edit_text);
        searchButton = findViewById(R.id.search_button);
        imageSearchButton = findViewById(R.id.image_search_button);
        audioSearchButton = findViewById(R.id.audio_search_button);

        audioSearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}

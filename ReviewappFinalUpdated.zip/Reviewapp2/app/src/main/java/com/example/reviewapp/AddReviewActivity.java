package com.example.reviewapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddReviewActivity extends AppCompatActivity {
    private com.example.reviewapp.ReviewDAO reviewDAO;
    private EditText etUserName, etReviewText, etRating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_review);

        reviewDAO = new com.example.reviewapp.ReviewDAO(this);
        reviewDAO.open();

        etUserName = findViewById(R.id.etUserName);
        etReviewText = findViewById(R.id.etReviewText);
        etRating = findViewById(R.id.etRating);
        Button btnSubmitReview = findViewById(R.id.btnSubmitReview);

        btnSubmitReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int rating = Integer.parseInt(etRating.getText().toString());
                    if (rating < 1 || rating > 5) {
                        Toast.makeText(AddReviewActivity.this, "Rating must be between 1 and 5", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    com.example.reviewapp.Review review = new com.example.reviewapp.Review(
                            0, // ID is auto-generated
                            rating,
                            etReviewText.getText().toString(),
                            etUserName.getText().toString());

                    reviewDAO.addReview(review);
                    finish(); // Close this activity and go back
                } catch (NumberFormatException e) {
                    Toast.makeText(AddReviewActivity.this, "Invalid rating", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        reviewDAO.close();
        super.onDestroy();
    }
}

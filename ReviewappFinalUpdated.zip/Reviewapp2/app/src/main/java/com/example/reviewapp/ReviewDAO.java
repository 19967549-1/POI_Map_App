package com.example.reviewapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class ReviewDAO {
    private SQLiteDatabase db;
    private com.example.reviewapp.DatabaseHelper dbHelper;

    public ReviewDAO(Context context) {
        dbHelper = new com.example.reviewapp.DatabaseHelper(context);
    }

    public void open() {
        db = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public boolean addReview(com.example.reviewapp.Review review) {
        ContentValues values = new ContentValues();
        values.put(com.example.reviewapp.DatabaseHelper.COLUMN_USER_NAME, review.getUserName());
        values.put(com.example.reviewapp.DatabaseHelper.COLUMN_REVIEW_TEXT, review.getReviewText());
        values.put(com.example.reviewapp.DatabaseHelper.COLUMN_RATING, review.getRating());

        long result = db.insert(com.example.reviewapp.DatabaseHelper.TABLE_REVIEWS, null, values);
        return (result != -1);
    }

    public List<com.example.reviewapp.Review> getAllReviews() {
        List<com.example.reviewapp.Review> reviews = new ArrayList<>();
        Cursor cursor = db.query(com.example.reviewapp.DatabaseHelper.TABLE_REVIEWS, new String[] {
                com.example.reviewapp.DatabaseHelper.COLUMN_ID,
                com.example.reviewapp.DatabaseHelper.COLUMN_USER_NAME,
                com.example.reviewapp.DatabaseHelper.COLUMN_REVIEW_TEXT,
                com.example.reviewapp.DatabaseHelper.COLUMN_RATING
        }, null, null, null, null, null);

        while (cursor.moveToNext()) {
            com.example.reviewapp.Review review = new com.example.reviewapp.Review(
                    cursor.getInt(cursor.getColumnIndex(com.example.reviewapp.DatabaseHelper.COLUMN_ID)),
                    cursor.getInt(cursor.getColumnIndex(com.example.reviewapp.DatabaseHelper.COLUMN_RATING)),
                    cursor.getString(cursor.getColumnIndex(com.example.reviewapp.DatabaseHelper.COLUMN_REVIEW_TEXT)),
                    cursor.getString(cursor.getColumnIndex(com.example.reviewapp.DatabaseHelper.COLUMN_USER_NAME))
            );
            reviews.add(review);
        }
        cursor.close();
        return reviews;
    }
}

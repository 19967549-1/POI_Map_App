package com.example.reviewapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ReviewViewHolder> {
    private List<com.example.reviewapp.Review> reviewList;

    public ReviewAdapter(List<com.example.reviewapp.Review> reviewList) {
        this.reviewList = reviewList;
    }

    @NonNull
    @Override
    public ReviewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.review_item, parent, false);
        return new ReviewViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ReviewViewHolder holder, int position) {
        com.example.reviewapp.Review currentReview = reviewList.get(position);
        holder.userName.setText(currentReview.getUserName());
        holder.reviewText.setText(currentReview.getReviewText());
        holder.rating.setText(String.valueOf(currentReview.getRating()));
    }

    @Override
    public int getItemCount() {
        return (reviewList == null) ? 0 : reviewList.size();
    }

    public void setReviews(List<com.example.reviewapp.Review> reviews) {
        this.reviewList = reviews;
        notifyDataSetChanged();
    }

    static class ReviewViewHolder extends RecyclerView.ViewHolder {
        TextView userName, reviewText, rating;

        ReviewViewHolder(View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.tvUserName);
            reviewText = itemView.findViewById(R.id.tvReviewText);
            rating = itemView.findViewById(R.id.tvRating);
        }
    }
}

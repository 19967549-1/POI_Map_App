package com.example.reviewapp;

public class Review {
    private int id;
    private int rating;
    private String reviewText;
    private String userName;

    public Review(int id, int rating, String reviewText, String userName) {
        this.id = id;
        this.rating = rating;
        this.reviewText = reviewText;
        this.userName = userName;
    }

    // Getters and setters
    public int getId() { return id; }
    public int getRating() { return rating; }
    public String getReviewText() { return reviewText; }
    public String getUserName() { return userName; }
}

package com.example.reviewapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

public class ReviewsActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private com.example.reviewapp.ReviewAdapter adapter;
    private com.example.reviewapp.ReviewDAO reviewDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reviews);

        reviewDAO = new com.example.reviewapp.ReviewDAO(this);
        reviewDAO.open();

        recyclerView = findViewById(R.id.recyclerViewReviews);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new com.example.reviewapp.ReviewAdapter(reviewDAO.getAllReviews());
        recyclerView.setAdapter(adapter);

        Button btnAddReview = findViewById(R.id.btnAddReview);
        btnAddReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start an activity to add a review
                startActivity(new Intent(ReviewsActivity.this, com.example.reviewapp.AddReviewActivity.class));
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter.setReviews(reviewDAO.getAllReviews());
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onDestroy() {
        reviewDAO.close();
        super.onDestroy();
    }
}

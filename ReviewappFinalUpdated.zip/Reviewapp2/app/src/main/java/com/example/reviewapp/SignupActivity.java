package com.example.reviewapp;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class SignupActivity extends AppCompatActivity {

    Button create_user = null;
    EditText username, pass = null;
    byte[] plaintext,ciphertext,iv,digest;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        try {
            username = findViewById(R.id.editUserName);
            pass = findViewById(R.id.editPassword);
            create_user = findViewById(R.id.create_user);
        }catch (NullPointerException e){
            Log.d(TAG,"Cannot create new user data. Please try again later!\n");
        }
        create_user.setOnClickListener(v -> {
           // EditText usernameDisp = username;
           // EditText passwordDisp = pass;
          //  try {
           // }catch(NullPointerException e){
           //     throw new NullPointerException("Cannot create user, please try again later!");
           // }
            try {
                addPOI_LoginData(v);
                startActivity(new Intent(SignupActivity.this, ReviewsActivity.class));
            } catch (NoSuchPaddingException | IllegalBlockSizeException |
                     NoSuchAlgorithmException | BadPaddingException | InvalidKeyException e) {
                throw new RuntimeException(e);
            }
        });
        db = FirebaseFirestore.getInstance();
    }

    private void addPOI_LoginData(View view) throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException {
//        String passwordMessageDigest = genMessageDigest(pass.getText().toString());
        Map<String, Object> loginDetails= new HashMap<>();
     /*  byte[] message = pass.getText().toString().getBytes();
       MessageDigest md = MessageDigest.getInstance("SHA-512");
       digest = md.digest(message);*/
        //char [] readableMessageDigest = Arrays.toString(digest).toCharArray();

        boolean isUsernameEmpty = true;
        boolean isPasswordEmpty = true;
        // Test 0: Username is empty?
        if(username.getText().toString().isEmpty()) {
            isUsernameEmpty = username.getText().toString().isEmpty();
            Log.d(TAG,"Username is empty: " + username.getText().toString().isEmpty() + "\n");
        }else{
            isUsernameEmpty = username.getText().toString().isEmpty();
            Log.d(TAG,"Username is empty: " + username.getText().toString().isEmpty() + "\n");
        }

        // Test 1: Password is empty?
        if(pass.getText().toString().isEmpty()) {
            isPasswordEmpty = pass.getText().toString().isEmpty();
            Log.d(TAG,"Password is empty: " + pass.getText().toString().isEmpty() + "\n");
        }else {
            isPasswordEmpty = pass.getText().toString().isEmpty();
            Log.d(TAG, "Password is empty: " + pass.getText().toString().isEmpty() + "\n");
        }

        // Below is not a test:
        if(isUsernameEmpty != true && isPasswordEmpty != true){
            loginDetails.put("Username", username.getText().toString());
            //loginDetails.put("Password", encrypt(pass.getText().toString()));
            // loginDetails.put("Password", readableMessageDigest[0]);
            // loginDetails.put("Password", pass.getText().toString());
            loginDetails.put("Password", Arrays.toString(encrypt(pass.getText().toString())));
            db.collection("login_details")
                    .add(loginDetails)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            Log.d("DocumentSnapshot added with ID: ", "DocumentSnapshot added with ID: "
                                    + documentReference.getId());
                        }
                    })

                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.d(TAG, "Error adding document", e);
                        }
                    });
        }

    } // END addPOI_LoginData METHOD

    private byte[] encrypt(String message) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        plaintext = message.getBytes();
        KeyGenerator keygen = KeyGenerator.getInstance("AES");
        keygen.init(256);
        SecretKey key = keygen.generateKey();
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        ciphertext = cipher.doFinal(plaintext);
        iv = cipher.getIV();
        //char [] readableCipherText = new char[ciphertext.length];
        return ciphertext;
    } // END encrypt METHOD


    /*@Override
    public void onResume() {
        super.onResume();
        try {
            addPOI_LoginData(create_user);
        } catch (NoSuchPaddingException | IllegalBlockSizeException | NoSuchAlgorithmException |
                 BadPaddingException | InvalidKeyException e) {
            throw new RuntimeException(e);
        }
      
    }*/


   /* @Override
    protected  void onStart() {
        super.onStart();
        startActivity(new Intent(SignupActivity.this, ReviewsActivity.class));
    }*/
}


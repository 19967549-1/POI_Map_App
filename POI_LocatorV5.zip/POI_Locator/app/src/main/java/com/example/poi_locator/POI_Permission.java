package com.example.poi_locator;

import android.Manifest;
import android.content.Context;
import android.content.res.AssetManager;

import androidx.core.app.ActivityCompat;
import android.content.pm.PackageManager;
import android.content.res.Resources;

public class POI_Permission {
    //abstract class POI_Permission  {
        //extends Context {
        //Require permissions array
        //final String[] PERMISSIONS = {android.Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};

         //POI_Permission(){}


   /* @Override
    public Resources getResources() {
        return null;
    }

    //Helper function to check permission status
        public boolean hasPermissions() {
            boolean permissionStatus = true;
            for (String permission : PERMISSIONS) {
                if (ActivityCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {


                }
            } // END FOREACH LOOP
            return permissionStatus;
        } // END hasPermission METHOD

 */
} // END POI_LOCATION Class

package com.example.poi_locator;

//import android.content.Intent;

//import androidx.activity.result.ActivityResultCallback;
//import androidx.activity.result.ActivityResultLauncher;

//import com.firebase.ui.auth.FirebaseAuthUIActivityResultContract;
//import com.firebase.ui.auth.data.model.FirebaseAuthUIAuthenticationResult;

public class FirebaseUI_Activity {

}

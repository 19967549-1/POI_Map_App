package com.example.poi_locator;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import static android.os.Message.*;

public class POI_SQL {

}

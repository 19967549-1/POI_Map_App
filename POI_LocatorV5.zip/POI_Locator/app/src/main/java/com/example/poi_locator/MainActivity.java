package com.example.poi_locator;

//import static com.example.poi_locator.Message.message;
import static android.content.ContentValues.TAG;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

//import androidx.activity.result.ActivityResultCallback;
//import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
// import com.example.POI_POI_Permission;
import android.util.Log;
import android.widget.EditText;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.ContentValues;
import android.content.Context;

//import com.firebase.ui.auth.IdpResponse;
//import com.firebase.ui.auth.AuthUI;
//import com.firebase.ui.auth.FirebaseAuthUIActivityResultContract;/import com.firebase.ui.auth.data.model.FirebaseAuthUIAuthenticationResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;


import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.auth.FirebaseUser;

import com.google.firebase.firestore.DocumentReference;
//import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

//import java.util.Arrays;
import java.util.HashMap;
//import java.util.List;
import java.util.Map;

/*import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;*/

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

       Button create_user = null;

        EditText username, pass;

        FirebaseFirestore db;
        //DocumentReference docRef;

    //Intent signInIntent =
    //List<AuthUI.IdpConfig> providers;

        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            username = (EditText) findViewById(R.id.editUserName);
            pass = (EditText) findViewById(R.id.editPassword);
            create_user = (Button) findViewById(R.id.create_user);

            create_user.setOnClickListener(this::addPOI_LoginData);
            db = FirebaseFirestore.getInstance();

          /*  final ActivityResultLauncher<Intent> signInLauncher = registerForActivityResult(
                    new FirebaseAuthUIActivityResultContract(),
                    new ActivityResultCallback<FirebaseAuthUIAuthenticationResult>() {
                        @Override
                        public void onActivityResult(FirebaseAuthUIAuthenticationResult result) {
                            onSignInResult(result);
                        }
                    }
            );

            // This code is from https://firebase.google.com/docs/auth/android/firebaseui#java
            // Choose authentication providers
            List<AuthUI.IdpConfig> providers = Arrays.asList(
                    new AuthUI.IdpConfig.EmailBuilder().build(),
                    new AuthUI.IdpConfig.PhoneBuilder().build(),
                    new AuthUI.IdpConfig.GoogleBuilder().build(),
                    new AuthUI.IdpConfig.FacebookBuilder().build(),
                    new AuthUI.IdpConfig.TwitterBuilder().build());

            // This code is from https://firebase.google.com/docs/auth/android/firebaseui#java
// Create and launch sign-in intent
            Intent signInIntent = AuthUI.getInstance()
                    .createSignInIntentBuilder()
                    .setAvailableProviders(providers)
                    .build();
            signInLauncher.launch(signInIntent);
*/
            // docRef = db.collection("POI_login").document("pj1ePkZ9mfHsgBHkgjps");
            // docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {

                 // @param task

            // @Override
             /*    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                        } else {
                            Log.d(TAG, "No such document");
                        }
                    } else {
                        Log.d(TAG, "get failed with ", task.getException());
                    }
                }
            });
            */

       } // END onCreate METHOD

        private void addPOI_LoginData(View view) {
            Map<String, Object> loginDetails= new HashMap<>();

            loginDetails.put("Username",username.getText().toString());
            loginDetails.put("Password",pass.getText().toString());

            db.collection("login_details")
                    .add(loginDetails)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            Log.d("DocumentSnapshot added with ID: ", "DocumentSnapshot added with ID: "
                                    + documentReference.getId());
                        }
                    })

                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.d(TAG, "Error adding document", e);
                        }
                    });
        } // END addPOI_LoginData METHOD


        @Override
        public void onClick(View view) {
            if (view.getId()==R.id.create_user) {
                if (create_user != null) {
                    create_user.setText("");
                }
            }
        }


    // onSignInResult code is from https://firebase.google.com/docs/auth/android/firebaseui#java
  /*  private void onSignInResult(FirebaseAuthUIAuthenticationResult result) {
        IdpResponse response = result.getIdpResponse();
        if (result.getResultCode() == RESULT_OK) {
            // Successfully signed in
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            // ...
        } else {
            // Sign in failed. If response is null the user canceled the
            // sign-in flow using the back button. Otherwise check
            // response.getError().getErrorCode() and handle the error.
            // ...
        }
    } */

        // Android Cryptography methods to add and move to separate Cryptography java file in testing phase.
          /* private void encryptMessage(String message) throws IllegalBlockSizeException, BadPaddingException {
                 int messageByteLen = message.getBytes().length;
                 byte[] plainText = new byte[messageByteLen];
               KeyGenerator keygen = KeyGenerator.getInstance("AES");
               keygen.init(256);
               SecretKey key = keygen.generateKey();
               Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
               cipher.init(Cipher.ENCRYPT_MODE, key);
               byte[] ciphertext = cipher.doFinal(plainText);
               byte[] iv = cipher.getIV()
           }*/

    // See: https://developer.android.com/training/basics/intents/result


    /*private final void chooseAuthProviders() {
        // Choose authentication providers
             providers = Arrays.asList(
                new AuthUI.IdpConfig.EmailBuilder().build(),
                new AuthUI.IdpConfig.PhoneBuilder().build(),
                new AuthUI.IdpConfig.GoogleBuilder().build(),
                new AuthUI.IdpConfig.FacebookBuilder().build(),
                new AuthUI.IdpConfig.TwitterBuilder().build());
    }

    private final void createSignInIntent() {
        // Create and launch sign-in intent
         AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(providers)
                .build();
        signInLauncher.launch(signInIntent);
    }
*/


    } // END MainActivity CLASS

